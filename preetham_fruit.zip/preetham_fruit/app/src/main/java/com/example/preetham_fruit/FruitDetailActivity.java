package com.example.preetham_fruit;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class FruitDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fruit_detail);

        ImageView fruitImageView = findViewById(R.id.fruitImage);
        TextView fruitNameTextView = findViewById(R.id.fruitNameTextView);
        TextView fruitDescriptionTextView = findViewById(R.id.fruitDescriptionTextView);

        // Get data from intent
        String fruitName = getIntent().getStringExtra("fruitName");
        String fruitDescription = getIntent().getStringExtra("fruitDescription");
        int fruitImageResourceId = getIntent().getIntExtra("fruitItem", 0);

        if (fruitName != null && fruitDescription != null && fruitImageResourceId != 0) {
            // Set data to views
            fruitImageView.setImageResource(fruitImageResourceId);
            fruitNameTextView.setText(fruitName);
            fruitDescriptionTextView.setText(fruitDescription);
        }
    }
}
