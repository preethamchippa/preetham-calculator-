package com.example.preetham_fruit;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.preetham_fruit.FruitDetailActivity;
import com.example.preetham_fruit.R;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayAdapter<FruitItem> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        FruitItem[] fruitItems = {
                new FruitItem("Apple", "The scientific name of apple is Malus domestica.", R.drawable.apple),
                new FruitItem("Grapes", "The scientific name of grapes is Vitis vinifera.", R.drawable.grapes),
                new FruitItem("Banana", "The scientific name of banana is Musa acuminata.", R.drawable.banana),
                new FruitItem("Coconut", "The scientific name of coconut is Cocos nucifera. ", R.drawable.coconut),
                new FruitItem("Orange", "The scientific name of coconut is Citrus sinensis. ", R.drawable.orange),
                new FruitItem("Pineapple", "The scientific name of coconut is Ananas comosus. ", R.drawable.pineapple),
                new FruitItem("Watermelon", "The scientific name of coconut is Citrullus lanatus. ", R.drawable.watermelon),
        };


        adapter = new CustomFruitAdapter(this, R.layout.custom_list_item, fruitItems);
        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Start a new activity with the selected item's details
                Intent intent = new Intent(MainActivity.this, FruitDetailActivity.class);
                intent.putExtra("fruitName", fruitItems[position].getName());
                intent.putExtra("fruitDescription", fruitItems[position].getDescription());
                intent.putExtra("fruitItem", fruitItems[position].getImageResourceId());
                startActivity(intent);
            }
        });
    }
}

