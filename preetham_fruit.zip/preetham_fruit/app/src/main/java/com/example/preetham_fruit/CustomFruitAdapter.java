package com.example.preetham_fruit;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.example.preetham_fruit.FruitItem;
import com.example.preetham_fruit.R;

public class CustomFruitAdapter extends ArrayAdapter<FruitItem> {

    public CustomFruitAdapter(Context context, int resource, FruitItem[] objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.custom_list_item, parent, false);
        }

        FruitItem fruitItem = getItem(position);

        TextView fruitNameTextView = convertView.findViewById(R.id.fruitNameTextView);
        ImageView fruitImageView = convertView.findViewById(R.id.fruitImageView);

        if (fruitItem != null) {
            fruitNameTextView.setText(fruitItem.getName());
            fruitImageView.setImageResource(fruitItem.getImageResourceId());

        }

        return convertView;
    }
}