package com.example.pchippaassignment_3;

import androidx.annotation.NonNull;

import java.io.Serializable;

public class Note implements Serializable {
    private String title;
    private String content;

    public Note(String title, String content) {
        this.title = title;
        this.content = content;
    }
    public Note(String content) {
        this.content = content;
    }

    @NonNull
    @Override
    public String toString() {
        return content;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }
}
