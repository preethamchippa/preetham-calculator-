package com.example.pchippaassignment_3;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Button;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MyViewNoteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_view_note);

        TextView titleTextView = findViewById(R.id.titleTextView);
        TextView bodyTextView = findViewById(R.id.bodyTextView);
        Button closeButton = findViewById(R.id.closeButton);

        Note note = (Note) getIntent().getSerializableExtra("note");

        if (note != null) {
            titleTextView.setText(note.getTitle());
            bodyTextView.setText(note.getContent());
        }

        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeViewNoteActivity();
            }
        });
    }

    private void closeViewNoteActivity() {
        finish();
    }
}


