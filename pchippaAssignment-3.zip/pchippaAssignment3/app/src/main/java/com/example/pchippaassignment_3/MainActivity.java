package com.example.pchippaassignment_3;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final int ADD_NOTE_REQUEST_CODE = 1;

    private List<Note> noteList = new ArrayList<Note>();
    private ArrayAdapter<Note> noteArrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView noteListView = findViewById(R.id.noteListView);
        Button addNoteButton = findViewById(R.id.addNoteButton);

        noteArrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, noteList);

        noteListView.setAdapter(noteArrayAdapter);

        addNoteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startAddNoteActivity();
            }
        });

        noteListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                openViewNoteActivity(position);
            }
        });
    }

    private void startAddNoteActivity() {
        Intent intent = new Intent(this, AddMyNoteActivity.class);
        startActivityForResult(intent, ADD_NOTE_REQUEST_CODE);
    }

    private void openViewNoteActivity(int position) {
        Intent intent = new Intent(this, MyViewNoteActivity.class);
        intent.putExtra("note", noteList.get(position).toString());
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_NOTE_REQUEST_CODE && resultCode == RESULT_OK) {
            if (data != null) {
                String noteString = data.getStringExtra("newNote");
                if (noteString != null) {
                    Note newNote = new Note(noteString);
                    noteList.add(newNote);
                    noteArrayAdapter.notifyDataSetChanged();
                }
            }
        }
    }
}
