package com.example.pchippaassignment_3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class AddMyNoteActivity extends AppCompatActivity {
    private EditText titleEditText;
    private EditText bodyEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_my_note);

        titleEditText = findViewById(R.id.titleEditText);
        bodyEditText = findViewById(R.id.bodyEditText);
        Button saveButton = findViewById(R.id.saveButton);
        Button cancelButton = findViewById(R.id.cancelButton);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                saveNote();
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cancelNote();
            }
        });
    }

    private void saveNote() {
        String title = titleEditText.getText().toString();
        String body = bodyEditText.getText().toString();

        if (!title.isEmpty() && !body.isEmpty()) {
            Note newNote = new Note(title, body);

            Intent intent = new Intent();
            intent.putExtra("newNote", newNote);

            setResult(RESULT_OK, intent);

            finish();
        }
    }

    private void cancelNote() {
        setResult(RESULT_CANCELED);

        finish();
    }
}


