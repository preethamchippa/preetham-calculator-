package com.example.hangman_prefinal;

import android.content.Context;
import android.content.SharedPreferences;

public class GameStats {

    private SharedPreferences preferences;
    private static final String PREF_NAME = "HangmanStats";
    private static final String WINS_KEY = "wins";
    private static final String LOSSES_KEY = "losses";

    public GameStats(Context context) {
        preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void saveGameResult(boolean won) {
        int wins = preferences.getInt(WINS_KEY, 0);
        int losses = preferences.getInt(LOSSES_KEY, 0);
        SharedPreferences.Editor editor = preferences.edit();

        if (won) {
            editor.putInt(WINS_KEY, wins + 1);
        } else {
            editor.putInt(LOSSES_KEY, losses + 1);
        }
        editor.apply();
    }

    public void resetStats() {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(WINS_KEY, 0);
        editor.putInt(LOSSES_KEY, 0);
        editor.apply();
    }

    public int getWins() {
        return preferences.getInt(WINS_KEY, 0);
    }

    public int getLosses() {
        return preferences.getInt(LOSSES_KEY, 0);
    }
}
