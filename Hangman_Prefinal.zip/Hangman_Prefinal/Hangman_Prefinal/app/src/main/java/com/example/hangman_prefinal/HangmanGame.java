package com.example.hangman_prefinal;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.ImageView;

import java.util.Random;
import java.util.Set;
import java.util.HashSet;

public class HangmanGame {
    private String currentWord;
    private final Set<Character> guessedLetters;
    private int failedAttempts;
    private final SharedPreferences preferences;
    private final ImageView hangmanImage;
    private final MainActivity mainActivity;
    private int maxAttempts;

    // Constants for the difficulty levels
    private static final int EASY_MAX_ATTEMPTS = 6;
    private static final int MEDIUM_MAX_ATTEMPTS = 5;
    private static final int HARD_MAX_ATTEMPTS = 4;

    // Word lists for different difficulty levels
    private final String[] easyWords = {"apple", "ball", "cat"};
    private final String[] mediumWords = {"elephant", "giraffe", "hippopotamus"};
    private final String[] hardWords = {"encyclopedia", "juxtaposition", "quizzical"};

    public HangmanGame(Context context, ImageView hangmanImage, SharedPreferences prefs) {
        this.mainActivity = (MainActivity) context;
        this.preferences = prefs;
        this.hangmanImage = hangmanImage;
        this.guessedLetters = new HashSet<>();
        this.maxAttempts = EASY_MAX_ATTEMPTS;
        selectRandomWord(easyWords); // Start with an easy word
        resetGame();
    }

    public void checkGuess(String guess) {
        // Assuming guess is a single character since the keyboard provides single characters
        char guessedChar = guess.toLowerCase().charAt(0);

        if (guessedLetters.contains(guessedChar)) {
            // The character has already been guessed
            mainActivity.updateGameInfo("You've already guessed that letter.");
            return;
        }

        guessedLetters.add(guessedChar);
        boolean correctGuess = currentWord.indexOf(guessedChar) >= 0;

        if (!correctGuess) {
            failedAttempts++;
            if (failedAttempts >= maxAttempts) {
                // Player has lost the game
                updateStats(false);
                mainActivity.showGameOverDialog(false);
            }
        } else {
            if (isWordGuessed()) {
                // Player has won the game
                updateStats(true);
                mainActivity.showGameOverDialog(true);
            }
        }

        // Update the word displayed to the user and the image
        mainActivity.updateCurrentWord(getMaskedWord());
        updateHangmanImage();
    }

    private boolean isWordGuessed() {
        for (char letter : currentWord.toCharArray()) {
            if (!guessedLetters.contains(letter)) {
                return false;
            }
        }
        return true;
    }

    private String getMaskedWord() {
        StringBuilder maskedWord = new StringBuilder();
        for (char letter : currentWord.toCharArray()) {
            if (guessedLetters.contains(letter)) {
                maskedWord.append(letter);
            } else {
                maskedWord.append("_ ");
            }
        }
        return maskedWord.toString();
    }

    private void updateHangmanImage() {
        String resourceName = "hangman_image_" + (failedAttempts + 1);
        int resId = mainActivity.getResources().getIdentifier(resourceName, "drawable", mainActivity.getPackageName());

        // Check if the resource was found; if not, use a default image
        if (resId != 0) {
            hangmanImage.setImageResource(resId);
        }
    }

    public void setDifficulty(String difficulty) {
        switch (difficulty) {
            case "Easy":
                maxAttempts = EASY_MAX_ATTEMPTS;
                selectRandomWord(easyWords);
                break;
            case "Medium":
                maxAttempts = MEDIUM_MAX_ATTEMPTS;
                selectRandomWord(mediumWords);
                break;
            case "Hard":
                maxAttempts = HARD_MAX_ATTEMPTS;
                selectRandomWord(hardWords);
                break;
        }
        resetGame();
        mainActivity.resetKeyboard();
    }

    public void startNewGame() {
        // Select a random word from the current difficulty
        selectRandomWord(easyWords); // This should be based on the current difficulty
        resetGame();
        mainActivity.updateCurrentWord(getMaskedWord());
        updateHangmanImage();
        mainActivity.resetKeyboard();
    }

    private void selectRandomWord(String[] words) {
        Random random = new Random();
        currentWord = words[random.nextInt(words.length)].toLowerCase();
        resetDisplayWord();
    }
    private void resetDisplayWord() {
        mainActivity.updateCurrentWord(getMaskedWord());
    }

    private void resetGame() {
        failedAttempts = 0;
        guessedLetters.clear();
    }

    private void updateStats(boolean won) {
        int wins = preferences.getInt("wins", 0);
        int losses = preferences.getInt("losses", 0);
        SharedPreferences.Editor editor = preferences.edit();
        if (won) {
            editor.putInt("wins", wins + 1);
        } else {
            editor.putInt("losses", losses + 1);
        }
        editor.apply();
    }
}
