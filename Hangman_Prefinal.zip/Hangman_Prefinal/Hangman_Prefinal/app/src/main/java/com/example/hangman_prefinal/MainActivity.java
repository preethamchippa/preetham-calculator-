package com.example.hangman_prefinal;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    private EditText charInput;
    private Button submitButton, menuButton;
    private ImageView hangmanImage;
    private HangmanGame game;
    private GridLayout keyboardLayout;
    private ListView difficultyListView;
    private SharedPreferences sharedPreferences;
    private static final String PREFS = "HangmanStats";
    private TextView currentWordTextView;

    private GridView keyboardGridView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        hangmanImage = findViewById(R.id.hangmanImage);
        currentWordTextView = findViewById(R.id.currentWord);
        keyboardLayout = findViewById(R.id.keyboardLayout);
        difficultyListView = findViewById(R.id.difficultyListView);
        menuButton = findViewById(R.id.menuButton); // Make sure you have this in your layout
        keyboardLayout = findViewById(R.id.keyboardLayout);

        sharedPreferences = getSharedPreferences(PREFS, MODE_PRIVATE);
        game = new HangmanGame(this, hangmanImage, sharedPreferences);
        initializeKeyboard();


        setupDifficultyListView();
        setupMenuButton();
    }
    private void initializeKeyboard() {
        int numberOfKeys = 26; // For English alphabet A-Z
        float scale = getResources().getDisplayMetrics().density;
        int dpWidth = 40; // Desired width in dp
        int dpHeight = 40; // Desired height in dp
        int pixelWidth = (int) (dpWidth * scale + 0.5f); // Convert dp to pixels
        int pixelHeight = (int) (dpHeight * scale + 0.5f); // Convert dp to pixels

        for (int i = 0; i < numberOfKeys; i++) {
            Button button = new Button(this);
            char letter = (char) ('A' + i);
            button.setText(String.valueOf(letter));

            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = pixelWidth; // Set the fixed width in pixels
            params.height = pixelHeight; // Set the fixed height in pixels
            params.setMargins(3, 3, 3, 3); // Smaller margins
            button.setLayoutParams(params);

            button.setOnClickListener(v -> {
                game.checkGuess(String.valueOf(letter));
                button.setEnabled(false); // Disable the button after it's been clicked
            });

            keyboardLayout.addView(button);
        }
    }



    private void setupDifficultyListView() {
        String[] levels = {"Easy", "Medium", "Hard"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, levels);
        difficultyListView.setAdapter(adapter);
        difficultyListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String level = (String) parent.getItemAtPosition(position);
                game.setDifficulty(level);
            }
        });
    }

    private void setupMenuButton() {
        menuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popup = new PopupMenu(MainActivity.this, menuButton);
                // Manually adding menu items (hardcoded)
                popup.getMenu().add(Menu.NONE, 1, 1, "Show Stats");
                popup.getMenu().add(Menu.NONE, 2, 2, "Reset Stats");
                popup.getMenu().add(Menu.NONE, 3, 3, "New Game");

                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()) {
                            case 1: // Corresponds to "Show Stats"
                                showStats("Stats here"); // Modify as needed
                                return true;
                            case 2: // Corresponds to "Reset Stats"
                                resetStats();
                                return true;
                            case 3: // Corresponds to "New Game"
                                game.startNewGame();
                                return true;
                            default:
                                return false;
                        }
                    }
                });
                popup.show();
            }
        });
    }


    public void showStats(String message) {
        int wins = sharedPreferences.getInt("wins", 0);
        int losses = sharedPreferences.getInt("losses", 0);
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Game Stats");
        builder.setMessage("Wins: " + wins + "\nLosses: " + losses);
        builder.setPositiveButton("OK", null);
        builder.show();
    }

    public void resetKeyboard() {
        // Assuming keyboardLayout is a GridLayout containing your alphabet buttons
        for (int i = 0; i < keyboardLayout.getChildCount(); i++) {
            View view = keyboardLayout.getChildAt(i);
            if (view instanceof Button) {
                view.setEnabled(true); // Enable all buttons
            }
        }
    }


    public void updateGameInfo(String info) {
        Toast.makeText(this, info, Toast.LENGTH_SHORT).show();
    }


    private void resetStats() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("wins", 0);
        editor.putInt("losses", 0);
        editor.apply();
        Toast.makeText(this, "Stats reset successfully", Toast.LENGTH_SHORT).show();
    }

    public void showGameOverDialog(boolean won) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(won ? "You Win!" : "You Lose!");
        builder.setMessage(won ? "Congratulations! You guessed the word!" : "Better luck next time!");
        builder.setPositiveButton("New Game", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                game.startNewGame();
            }
        });
        builder.setNegativeButton("Cancel", null);
        builder.show();
    }
    public void updateCurrentWord(String currentWord) {
        currentWordTextView.setText(currentWord);
    }


    // Additional methods as needed...
}
