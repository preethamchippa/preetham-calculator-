package com.example.mytrackingexpenseapp;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private ListView expenseListView;
    private Button addExpenseButton;
    private ArrayAdapter<String> expenseAdapter;
    private ArrayList<String> expenses;
    private static final String FILE_NAME = "expenses.txt";
    private static final int EDIT_EXPENSE_REQUEST_CODE = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        expenseListView = findViewById(R.id.expenseListView);
        addExpenseButton = findViewById(R.id.addExpenseButton);

        expenses = loadExpensesFromFile();
        expenseAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, expenses);
        expenseListView.setAdapter(expenseAdapter);
        registerForContextMenu(expenseListView);

        expenseListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                expenseListView.setOnItemClickListener(null);

                String selectedExpense = expenses.get(position);
                Toast.makeText(MainActivity.this, "Clicked: " + selectedExpense, Toast.LENGTH_SHORT).show();
            }
        });

        addExpenseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddExpenseDialog();
            }
        });
    }

    private ArrayList<String> loadExpensesFromFile() {
        ArrayList<String> loadedExpenses = new ArrayList<>();

        try {
            FileInputStream fis = openFileInput(FILE_NAME);
            BufferedReader br = new BufferedReader(new InputStreamReader(fis));

            String line;
            while ((line = br.readLine()) != null) {
                loadedExpenses.add(line);
            }

            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return loadedExpenses;
    }
    private void saveExpensesToFile() {
        try (FileOutputStream fos = openFileOutput(FILE_NAME, Context.MODE_PRIVATE)) {
            for (String expense : expenses) {
                fos.write((expense + "\n").getBytes());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showAddExpenseDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Expense");

        View view = LayoutInflater.from(this).inflate(R.layout.add_expense_activity, null);
        builder.setView(view);

        final EditText expenseDescriptionEditText = view.findViewById(R.id.expenseDescription);
        final EditText amountExpendedEditText = view.findViewById(R.id.amountExpended);
        final EditText dateOfExpenseEditText = view.findViewById(R.id.dateOfExpense);

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateOfExpenseEditText.setText(dateFormat.format(new Date()));

        dateOfExpenseEditText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(dateOfExpenseEditText);
            }
        });

        builder.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String description = expenseDescriptionEditText.getText().toString();
                String amount = amountExpendedEditText.getText().toString();
                String date = dateOfExpenseEditText.getText().toString();

                if (!description.isEmpty() && !amount.isEmpty() && !date.isEmpty()) {
                    String newExpense = description + ": $" + amount + " on " + date;
                    expenses.add(newExpense);
                    expenseAdapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(MainActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();
    }

    private void showDatePickerDialog(final EditText dateEditText) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int day) {
                String selectedDate = year + "-" + (month + 1) + "-" + day;
                dateEditText.setText(selectedDate);
            }
        }, year, month, day);

        datePickerDialog.show();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater().inflate(R.menu.context_menu, menu); // Reference the context menu resource
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        int position = info.position;

        if (item.getItemId() == R.id.editExpense) {
            // Handle the "Edit" option, open EditExpenseActivity with selected expense data
            Log.d("ContextMenu", "Edit Expense selected at position: " + position);
            String selectedExpense = expenses.get(position); // Get the selected expense data
            Intent editIntent = new Intent(MainActivity.this, EditExpenseActivity.class);
            editIntent.putExtra("selectedExpense", selectedExpense);
            editIntent.putExtra("editedExpensePosition", position);
            startActivityForResult(editIntent, EDIT_EXPENSE_REQUEST_CODE);

            return true;
        } else if (item.getItemId() == R.id.deleteExpense) {
            // Handle the "Delete" option, remove the chosen expense from the list
            expenses.remove(position);
            expenseAdapter.notifyDataSetChanged();
            return true;
        }
        else if (item.getItemId() == R.id.cancelExpense) {
            return true;
        }

        return super.onContextItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == EDIT_EXPENSE_REQUEST_CODE && resultCode == RESULT_OK) {
            // Retrieve updated expense data and position from the intent
            String updatedExpense = data.getStringExtra("updatedExpense");
            int editedExpensePosition = data.getIntExtra("editedExpensePosition", -1);

            // Update the expense in the list
            if (editedExpensePosition >= 0 && editedExpensePosition < expenses.size()) {
                expenses.set(editedExpensePosition, updatedExpense);
                expenseAdapter.notifyDataSetChanged();
                saveExpensesToFile();
            }
        }
    }

}
