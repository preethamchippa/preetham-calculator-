package com.example.mytrackingexpenseapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class EditExpenseActivity extends AppCompatActivity {

    private ArrayList<String> expenses;
    private ArrayAdapter<String> expenseAdapter;
    private int editedExpensePosition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_expense_activity);

        String selectedExpense = getIntent().getStringExtra("selectedExpense");
        editedExpensePosition = getIntent().getIntExtra("editedExpensePosition", -1);

        EditText editExpenseDescription = findViewById(R.id.editExpenseDescription);
        EditText editAmountExpended = findViewById(R.id.editAmountExpended);
        EditText editDateOfExpense = findViewById(R.id.editDateOfExpense);

        if (selectedExpense != null && selectedExpense.contains(": $") && selectedExpense.contains(" on ")) {
            String[] expenseComponents = selectedExpense.split(": ");
            if (expenseComponents.length == 2) {
                String description = expenseComponents[0];
                String amountAndDate = expenseComponents[1];
                String[] amountAndDateComponents = amountAndDate.split(" on ");
                if (amountAndDateComponents.length == 2) {
                    String amount = amountAndDateComponents[0].replace("$", ""); // Remove the currency symbol
                    String date = amountAndDateComponents[1];
                    editExpenseDescription.setText(description);
                    editAmountExpended.setText(amount);
                    editDateOfExpense.setText(date);
                } else {
                    showErrorMessage();
                }
            } else {
                showErrorMessage();
            }
        } else {
            showErrorMessage();
        }
    }

    public void saveExpense(View view) {
        EditText editExpenseDescription = findViewById(R.id.editExpenseDescription);
        EditText editAmountExpended = findViewById(R.id.editAmountExpended);
        EditText editDateOfExpense = findViewById(R.id.editDateOfExpense);

        String editedDescription = editExpenseDescription.getText().toString();
        String editedAmount = editAmountExpended.getText().toString();
        String editedDate = editDateOfExpense.getText().toString();

        if (!editedDescription.isEmpty() && !editedAmount.isEmpty() && !editedDate.isEmpty()) {
            String updatedExpense = editedDescription + ": $" + editedAmount + " on " + editedDate;

            if (expenses == null) {
                expenses = new ArrayList<>();
            }

            if (editedExpensePosition >= 0 && editedExpensePosition < expenses.size()) {
                expenses.set(editedExpensePosition, updatedExpense);
            } else {
                expenses.add(updatedExpense);
            }

            if (expenseAdapter != null) {
                expenseAdapter.notifyDataSetChanged();
            }
            Intent resultIntent = new Intent();
            resultIntent.putExtra("updatedExpense", updatedExpense);
            resultIntent.putExtra("editedExpensePosition", editedExpensePosition);
            setResult(RESULT_OK, resultIntent);
            finish();
        } else {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
        }
    }
    public void cancelEdit(View view) {
        setResult(RESULT_CANCELED); // Set result as canceled
        finish(); // Finish the activity
    }
    private void showErrorMessage() {
        Toast.makeText(this, "Error: Unable to parse expense data", Toast.LENGTH_SHORT).show();
        finish(); // Close the EditExpenseActivity
    }
}

